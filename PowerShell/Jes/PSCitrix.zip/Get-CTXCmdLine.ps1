$erroractionpreference = "SilentlyContinue"
$Start = Get-Date
Write-Host "Started:" $Start.ToString()
$farm = new-Object -com "MetaframeCOM.MetaframeFarm"
$farm.Initialize(1)
$OutFile = $farm.FarmName + "-CmdLine.csv"
$Reported = 0
$Apps = 0

$AppsTable = New-Object system.Data.DataTable "AppsTable" # Setup the Datatable Structure
$col1 = New-Object system.Data.DataColumn Application,([string])
$col2 = New-Object system.Data.DataColumn Path,([string])
$col3 = New-Object system.Data.DataColumn Folder,([string])
$col4 = New-Object system.Data.DataColumn Office_Launching,([string])
$col5 = New-Object system.Data.DataColumn In_Wrapper,([string])
$col6 = New-Object system.Data.DataColumn Servers,([string])

$AppsTable.columns.add($col1)
$AppsTable.columns.add($col2)
$AppsTable.columns.add($col3)
$AppsTable.columns.add($col4)
$AppsTable.columns.add($col5)
$AppsTable.columns.add($col6)

$Applications = $farm.Applications
$Apps = $Applications.Count
Write-Host $Apps "applications to query in" $farm.FarmName

Foreach($App in $Applications) {
	if ($farm.FarmName -match "cps_farm") {
		$App.LoadData($True)
	}
	$Reported += 1
	
	Foreach($Server in $App.Servers) {
		if ($App.WinAppObject.DefaultInitProg -match "office") {
			$OfficeLaunch = "Yes"
		} else {
			$OfficeLaunch = "No"
		}
		
		if ($App.WinAppObject.DefaultInitProg -match ".cmd" -or $App.WinAppObject.DefaultInitProg -match ".vbs" -or $App.WinAppObject.DefaultInitProg -match ".bat") {
			$Error.Clear()
			
			if ($App.WinAppObject.DefaultInitProg -match "dfsroot" -or $App.WinAppObject.DefaultInitProg -match "\\\\") {
				$CmdLine = $App.WinAppObject.DefaultInitProg
			} else {
				$CmdLine = "\\" + $Server.ServerName + "\" + $App.WinAppObject.DefaultInitProg
				$CmdLine1 =  $CmdLine.Replace("c:\windows\system32\","")
				$CmdLine2 =  $CmdLine1.Replace("%windir%\system32\","")
				$CmdLine3 =  $CmdLine2.Replace("%systemroot%\system32\","")
				$CmdLine4 =  $CmdLine3.Replace("wscript.exe ","")
				$CmdLine5 =  $CmdLine4.Replace("wscript ","")
				$CmdLine6 =  $CmdLine5.Replace("cscript.exe ","")
				$CmdLine7 =  $CmdLine6.Replace("cscript ","")
				$CmdLine8 =  $CmdLine7.Replace(" //NoLogo","")
				$CmdLine9 =  $CmdLine8.Replace(" /NoLogo","")
				$CmdLine10 =  $CmdLine9.Replace(" -nowin","")
				$CmdLine11 =  $CmdLine10.Replace(":","$")
				$CmdLine12 =  $CmdLine11.Replace("`"","")
				$CmdLine = $CmdLine12
			}
			$Contains = (Get-Content $CmdLine | Where {$_ -match "office"}).Count
			if ($Contains -gt 0) {
				$InWrapper = "Yes"
			} elseif ($Error) {
				$InWrapper = "Unknown"
				$Error.Clear()
			} else {
				$InWrapper = "No"
			}
		} else {
			$InWrapper = "No"
		}
		
		$row = $AppsTable.NewRow()
		$row.Application = $App.BrowserName
		$row.Path = $App.WinAppObject.DefaultInitProg
		$row.Folder = $App.ParentFolderDN
		$row.Office_Launching = $OfficeLaunch
		$row.In_Wrapper = $InWrapper
		$row.Servers = $Server.ServerName
		$AppsTable.Rows.Add($row)
	}
	
	if (($Reported % 15) -eq 0 -or $Reported -eq $Apps -and $Reported -ne 0) {
		Write-Host " " $Reported "of" $Apps "Apps reported"
	}
}

$AppsTable | Export-Csv $OutFile -NoTypeInformation
$End = Get-Date
Write-Host "Finished:" $End.ToString()
Write-Host "Runtime:" ($End - $Start)