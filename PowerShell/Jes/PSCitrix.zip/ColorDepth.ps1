$farm = new-Object -com "MetaframeCOM.MetaframeFarm"
$farm.Initialize(1)

foreach($app in $farm.Applications) {
	$AppName = $app.DistinguishedName
	$Color = $app.WinAppObject.DefaultWindowColor
	Write-Host "$AppName`t$Color"
	"$AppName`t$Color" >> "ColorDepth.txt"
}