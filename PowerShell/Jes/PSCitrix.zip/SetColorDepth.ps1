$farm = new-Object -com "MetaframeCOM.MetaframeFarm"
$farm.Initialize(1)
$FarmName = $farm.FarmName
$LogFile = "$FarmName-SetColorLog.txt"
"Application Name`tOriginal Color Value`tNew Color Value" > $LogFile

$help = "`nThis script is used to set the color depth settings for Citrix Application.`n" + 
		"This script must be run from a computer/server with MFCOM registered for the`n" +
		"farm you wish to work with.  This script requires you to pass it 2 parameters:`n" +
		"`tFileName.txt = text file with a list of application names in it.  1 app per line`n" +
		"`t ColorDepth = a numeric value to indicate the color depth you wish to set.`n`n" +
		"Switches:`n" +
		"`t-h  -  Displays this help message`n" +
		"`t-a  -  Displays script about information`n" +
		"Usage:`n" +
		"`t./SetColorDepth.ps1 <input file name> <color depth value>`n`n" +
		"Example:`n" +
		"`t./SetColorDepth.ps1 file.txt 16`n" + 
		"`t./SetColorDepth.ps1 -h`n" +
		"`t./SetColorDepth.ps1 -a`n`n" +
		"Color Depth values:`n" + 
		"`t1 = 16 Colors`n" + 
		"`t2 = 256 Colors`n" + 
		"`t3 = High Color (16 bit)`n" + 
		"`t4 = 16 True Color(24 bit)`n"

$about = "`nSetColorDepth.ps1 v1.0`n" +
		 "This script was written by Nick Sandmann on 02/11/2009`n" +
		 "nick_sandmann@cargill.com`n"	
		 
If($args.Count -lt 1) {
	Write-Host -foregroundcolor red -backgroundcolor yellow "`nThis script atleast 1 argument!!!"
	Write-Host $help
	Exit
}
If($args.Count -gt 2) {
	Write-Host -foregroundcolor red -backgroundcolor yellow "`nThis script only accepts 2 argument!!!"
	Write-Host $help
	Exit	
}
ElseIf($args[0].ToLower() -eq "-h") { 
	Write-Host $help 
	Exit	
}
ElseIf($args[0].ToLower() -eq "-a") {	
	Write-Host $about
	Exit	
}
ElseIf($args.Count -ne 2) {
	Write-Host -foregroundcolor red -backgroundcolor yellow "`nThis script requires 2 argument!!!"
	Write-Host $help
	Exit
}

$AppsToSet = Get-Content $args[0]
$ColorDepth = $args[1]

foreach($app in $farm.Applications) {
	foreach($line in $AppsToSet) {
		if($line.Trim().ToLower() -eq $app.AppName.ToLower()) {
			$OldColorValue = $app.WinAppObject.DefaultWindowColor
			$app.WinAppObject.DefaultWindowColor = $ColorDepth
			$app.WinAppObject.SaveData()
			Write-Host $app.AppName ": Changed value from: $OldColorValue to $ColorDepth"
			$app.AppName + "`t" + $OldColorValue + "`t" + $ColorDepth >> $LogFile
			Clear-Variable OldColorValue
			break
		}		
	}
}
