  Secure-Folder.ps1
  Written by: Jes Brouillette (jes_brouillette@cargill.com)
  Last Modified:  06/12/09

  =============================================================================
  
  WARNING: THIS SCRIPT CAN TAKE SEVERAL HOURS TO REPLACE PERMISSIONS ON 
  FOLDERS.  CLOSING BEFORE THE SCRIPT FINISHED CAN CAUSE FOLDER PERMISSION
  ERRORS

  DO NOT USER FOR CREATING FOLDERS IN CLUSTERS.  THIS IS FOR STAND-ALONE
  SERVERS ONLY

  =============================================================================
  
  Note: 
    For best performance run from a machine on a network local to the server 
    where the shares and a Domain Controller reside
  
  Purpose:
    Secures folders according to the F&P standards as of Nov 2008.  This script
    will only create what has been specified in the .csv file.  You MUST
    validate the folder structure before running this script.  Please refrer to
    the MWTS KB for details:
    http://sharepoint.hosting.cargill.com/GHSKB/Forms/Default.aspx?RootFolder=%2fGHSKB%2fProcesses%2c%20Procedures%20and%20Decision%20Trees%2fMWTS%2fStandards%2fFile%20and%20Print&FolderCTID=0x0120000EE4023FBA876F4088B5F875FE5E904C&View=%7b56455794%2d47E5%2d472B%2d9085%2d140D93CE2358%7d
  
  Execution:
    1.)Gathers information from the csv file selected
    2.)Creates AD User Group 
    3.)Creates the folders, if they need created 
    4.)Adds the proper AD Security Group and settings for each folder
    5.)Adds users to the proper AD Security Group
  
  Switches: 
    -help - Displays the help message
    -csv - file to import (optional - you will be prompted if not specified) 
    -show - exports all groups and all settings to .csv files
    -remove - removes existing folder security before starting 
  
  Usage:
    .\Secure-Folder.ps1 (-help, -csv, -show, -remove) 
  
  CSV File Format:
    share,groupou,approve,modify,read
    [share],[groupou],[approver(s)],[modify_users],[read-only_users] 
  
  Where: 
    [share] = the full path to the folder
    [groupou] = the full LDAP path where the group will be created 
    (MUST be in Quotes if created in Notepad)
    [approver(s)] = approvers in the format [domain]\[username]
    [modify_users] = modify users in the format [domain]\[username]
    [read-only_users] = read-only users in the format [domain]\[username]
    
  **For multiple users in each group, use a semicolon (;) to sepearate users**