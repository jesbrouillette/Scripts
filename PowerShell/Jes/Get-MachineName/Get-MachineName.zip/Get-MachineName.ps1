param (
	[switch] $exc, #imports to Excel instead of a csv file
	[switch] $pta, #uses pass through authentication
	[switch] $os #attempts to get os version
)

###############################################################################
# Gather the machine name for a given IP                                      #
#                                                                             #
# Created By: Jes Brouillette                                                 #
# Creation Date: 08/11/09                                                     #
# Usage: .\Get-MachineName.ps1 <txt file of ip's>                             #
###############################################################################

$erroractionpreference = "SilentlyContinue"

function ToExcel ($ipAddress,$hostName,$OS,$err) {
	$worksheet.Cells.Item($col, $row) = $ipAddress
	if ($err) { $worksheet.Cells.Item($col, $row).Font.ColorIndex = 3 }
	$row = $row + 1
	$worksheet.Cells.Item($col, $row) = $hostName
	if ($err) { $worksheet.Cells.Item($col, $row).Font.ColorIndex = 3 }
	$col = $col + 1
}

function ToCSV ($ipAddress,$hostName,$OS) {
	$tRow = $table.NewRow()
	$tRow.IP = $ipAddress
	$tRow.DNS = $hostName
	$table.Rows.Add($tRow)
}

if (!$exc) { $outfile = "Get-MachineName.csv" }

# verifies input
if ($List -eq "") 
{
	Write-Host "Usage: .\Get-MachineName.ps1 IP";
	exit;
}
else
{
	if ($exc) {
		# starts an excel instance
		$excel = New-Object -comobject Excel.Application
		$excel.visible = $True 
		
		$workbook = $excel.Workbooks.Add()
		$worksheet = $workbook.Worksheets.Item(1)
		
		$col = 1
		$row = 1
	
		$worksheet.Cells.Item($col, $row) = "IP Address"
		$row = $row + 1
		$worksheet.Cells.Item($col, $row) = "DNS Name"
		$col = $col + 1
		$row = 1
	} else {
		$table = New-Object system.Data.DataTable ""
		$col1 = New-Object system.Data.DataColumn IP,([string])
		$col2 = New-Object system.Data.DataColumn DNS,([string])
		$table.Columns.Add($col1)
		$table.Columns.Add($col2)
	}
	#if (!$pta) { $cred = Get-Credential }
	$List = Get-Content $args[0]
	foreach($IP in $List)
	{

		# pings the servers to see if they are online
		$ping = new-object System.Net.NetworkInformation.Ping
		$Reply = $ping.send($IP)
	
		if ($Reply.status �eq "Success") 
		{
			# gathers all nic information for each nic in each server
			#if (!$pta) { $nics = get-wmiobject -class "Win32_NetworkAdapterConfiguration" -namespace "root\cimv2" �credential $cred -computername $IP | Where{$_.IpEnabled -Match "True"} }
			#else { $nics = get-wmiobject -class "Win32_NetworkAdapterConfiguration" -namespace "root\cimv2" -computername $IP | Where{$_.IpEnabled -Match "True"} }
			if ($nics -ne $null) {
				foreach ($nic in $nics)
				{
					# inputs results into excel
					$hostName = [system.net.dns]::GetHostEntry($IP).HostName
					if ($exc) { ToExcel $IP $hostName ; $col = $col + 1 }
					else { ToCSV $IP $hostName }
				}
			} else {
				$hostName = [system.net.dns]::GetHostEntry($IP).HostName
				if ($exc) { ToExcel $IP $hostName "1" ; $col = $col + 1 }
				else { ToCSV $IP $hostName }
			}
		}
		else 
		{
			# used only if the server is not reachable
			$hostName = "unknown"
			if ($exc) { ToExcel $IP $hostName "1" ; $col = $col + 1 }
			else { ToCSV $IP $hostName }
		}
		$Reply = ""
		$row = 1
	}
}

if ($exc) {
	$usedrange = $worksheet.UsedRange
	$filter = $usedrange.EntireColumn.AutoFilter()
	$fit = $usedrange.EntireColumn.AutoFit()
} else {
	$table | Select-Object IP,DNS
	$table | Select-Object IP,DNS | Export-Csv -NoTypeInformation $outfile
}