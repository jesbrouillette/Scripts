﻿$objExcel = New-Object -comobject Excel.Application
$objExcel.visible = $True

$intSheetNumb = 1
$objWorkbooks = $objExcel.Workbooks.Add()

$cred = Get-Credential

function GetInfo($strSrvr,$intSheet) {

	$intRow = 1
	$strSheet = "Sheet" + $intSheet
	
	$objWorksheets = $objWorkbooks.Worksheets | where {$_.name -eq $strSheet}
	$objWorksheets.Name = $strSrvr
		
	$objWorksheets.Cells.Item($intRow,1) = "Name"
	$objWorksheets.Cells.Item($intRow,2) = "Version"
	$objWorksheets.Cells.Item($intRow,3) = "Vendor"
	
	$objUsedRange = $objWorksheets.UsedRange
	$objUsedRange.Interior.ColorIndex = 19
	$objUsedRange.Font.ColorIndex = 11
	$objUsedRange.Font.Bold = $True
	
	$intRow = $intRow + 1

	$objWMI = Get-WmiObject -Namespace Root\CIMV2 -Class Win32_Product -ComputerName $strSrvr -Credential $cred
	
	foreach ($app in $objWMI) {
		$strDisplayName = $app.Name
		if ($strDisplayName -notlike "Security Update for*" -and $strDisplayName -notlike "Update for Windows*" -and $strDisplayName -notlike "*Hotfix*") {
			$strDisplayVersion = $app.Version
			$strPublisher = $app.Vendor
			
			$objWorksheets.Cells.Item($intRow,1) = $strDisplayName
			$objWorksheets.Cells.Item($intRow,2) = $strDisplayVersion
			$objWorksheets.Cells.Item($intRow,3) = $strPublisher
			$intRow = $intRow + 1
		}
	}
	$actFit = $objUsedRange.EntireColumn.AutoFit()
	$actFit = $objUsedRange.EntireColumn.AutoFilter()
	$objAddWorkSheet = ($objWorkbooks.sheets).add()
	#$objAddWorkSheet.add()
}

if ($args[0] -eq "multi") {
	$TextFileLocation=$args[1]
    $InFile = Get-Content "$TextFileLocation"
	foreach ($strSrvrName in $InFile) {
		GetInfo $strSrvrName $intSheetNumb
		$intSheetNumb = $intSheetNumb + 1
	}
}

if ($args[0] -eq "single") {
	$strSrvrName = $args[1]
	GetInfo $strSrvrName $intSheetNumb
}