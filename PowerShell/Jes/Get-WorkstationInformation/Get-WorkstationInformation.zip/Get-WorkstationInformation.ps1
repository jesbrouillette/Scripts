﻿Param (
	[string]$Computer
)
if (Test-Connection $Computer -Count 1 -Quiet) {
	$IPInfo = gwmi -query "Select IPAddress,DefaultIPGateway ,MACADDRESS FROM Win32_NetworkAdapterConfiguration WHERE IpEnabled='True'" -ComputerName $Computer
	$ComputerInfo = gwmi win32_computersystem -ComputerName $Computer | select Name,Model,Domain,Manufacturer
	$SerialNumber = (gwmi "Win32_BIOS" -ComputerName $Computer).SerialNumber
	"" | Select @{Name="Name";Expression={$ComputerInfo.Name}},`
		@{Name="Model";Expression={$ComputerInfo.Model}},`
		@{Name="Domain";Expression={$ComputerInfo.Domain}},`
		@{Name="Manufacturer";Expression={$ComputerInfo.Manufacturer}},`
		@{Name="IPAddress";Expression={$IPInfo | Select -ExpandProperty IPAddress}},`
		@{Name="DefaultIPGateway";Expression={$IPInfo | % {$_.DefaultIPGateway}}},`
		@{Name="MACAddress";Expression={$IPInfo | Select -ExpandProperty MACAddress}},`
		@{Name="SerialNumber";Expression={$SerialNumber}}
}
else {
	"" | Select @{Name="Name";Expression={$Computer}},Model,Domain,Manufaturer,@{Name="IPAddress";Expression={"Unavailable"}},DefaultIPGateway,MACAddress,SerialNumber
}