﻿param (
	$bucket		= "https://s3.amazonaws.com/JesB-East",		#S3 Bucket with install & config files
	$manifest	= "manifest.xml",							#XML file with install & config content
	$tempFolder	= "C:\Temp\Install-Apps"					#Temp location to dowload files into
)

# BEGIN FUNCTIONS

function UpdateRegistry {
	param (
		$path,
		$name,
		$value,
		$xmlTool
	)

	Write-Host "PS1INSTALLER: Starting registry action - $xmlTool"
	Write-Host "PS1INSTALLER: Registry Key path - $path"
	Write-Host "PS1INSTALLER: Registry Key name - $name"
	Write-Host "PS1INSTALLER: Registry Key value - $value"
	Write-Host "PS1INSTALLER: Setting registry $path $name $value"
	
	try { Set-ItemProperty -Path $path -Name $name -Value $value }
	catch { Write-Host "PS1INSTALLER: Error setting registry $path - $_" }
	finally { Write-Host "PS1INSTALLER: Finished registry action - $xmlTool" }
}

function CreateDirectory {
	param (
		[string]$path,
		[string]$name
	)
	if (!(Test-Path $path)) {

		Write-Host "PS1INSTALLER: Starting directory creation action - $name"
		Write-Host "PS1INSTALLER: Directory - $path"
		
		try { New-Item $path -ItemType Directory -ErrorAction Stop | Out-Null }
		catch { Write-Host "PS1INSTALLER: Error creating $path - $($_.GetType().FullName)" }
		finally { Write-Host "PS1INSTALLER: Finished directory action - $path" }

		Start-Sleep -Milliseconds 500
	}
}

function DownloadFile {
	param (
		[string]$source,
		[string]$destination,
		[string]$name
	)
	
	Write-Host "PS1INSTALLER: Starting download action - $name"
	Write-Host "PS1INSTALLER: Source - $source"
	Write-Host "PS1INSTALLER: Destination - $destination"

	$file = $source.Split("/")[-1]
	
	if ($destination.Length-1 -ne "\") { $destination = $destination + "\" + $file }
	else { $destination = $destination + $file }
	
	try {
		$wc.downloadfile($source,$destination)
	}
	catch [System.Net.WebException] {
		if($_.Exception.InnerException) { Write-Host "PS1INSTALLER: Error downloading $source to $destination - $($_.exception.innerexception.message)" }
		else { Write-Host "PS1INSTALLER: Error downloading $source - $_" }
	}
	catch {
		 Write-Host "PS1INSTALLER: Error downloading $source to $destination - $_"
	}
	finally {
		 Write-Host "PS1INSTALLER: Finished downloaded action - $name"
	}
}

function CopyFile {
	param (
		[string]$source,
		[string]$destination,
		[string]$name
	)
	
	Write-Host "PS1INSTALLER: Starting copy action - $name"
	Write-Host "PS1INSTALLER: Source - $source"
	Write-Host "PS1INSTALLER: Destination -  $destination"
	
	try { Copy-Item -path $source -Destination $destination -Force }
	catch { Write-Host "PS1INSTALLER: Error - $($_.GetType().FullName)" }
	finally { Write-Host "PS1INSTALLER: Finished file copy action - $name" }
}

function InstallApp {
	param (
		[string]$cmd,
		[string]$cmdArgs,
		[string]$xmlTool
	)
	Write-Host "PS1INSTALLER: Starting installation action - $xmlTool"
	Write-Host "PS1INSTALLER: Installer - $cmd"
	Write-Host "PS1INSTALLER: Arguements - $cmdArgs"

	try { Start-Process $cmd -ArgumentList $cmdArgs -Wait }
	catch { Write-Host "PS1INSTALLER: Error - $($_.GetType().FullName)" }
	finally { Write-Host "PS1INSTALLER: Finished installation action - $xmlTool" }
}

#END FUNCTIONS

$ErrorActionPreference = "Stop"	

#  Begin file downloads from S3
$wc = New-Object System.Net.WebClient

$srcManifest = "{0}/{1}" -f $bucket,$manifest
$localManifest = "{0}\{1}" -f $tempFolder,$manifest

CreateDirectory $tempFolder "manifest"
DownloadFile $srcManifest $tempFolder "manifest"

[xml]$xmlConfig = gc $localManifest

$installs = $xmlConfig.INSTALLS.INSTALL

foreach ($install in $installs) {

	$xmlName		= $install.NAME
	$xmlSrcRepos	= $install.REPOSITORY
	$xmlTools		= $install.TOOLS
	$xmlConfigItems	= $install.CONFIGITEMS
	$xmlTemp		= $install.TEMP
	$xmlDestination	= $install.DESTINATION
	
	$xmlSrcReposName		= $xmlSrcRepos.NAME
	$xmlSrcReposPath		= $xmlSrcRepos.PATH
	$xmlTempFolder			= $xmlTemp.PATH
	$xmlLocalDestination	= $xmlDestination.PATH	

	$xmlSrcFileName

	Write-Host "PS1INSTALLER: Starting action $xmlName"
	Write-Host "PS1INSTALLER: Repository - $xmlSrcReposName"
	Write-Host "PS1INSTALLER: Repository path - $xmlSrcReposPath"
	Write-Host "PS1INSTALLER: Local temp path - $xmlTempFolder"

	#-----local temp

	CreateDirectory $xmlTempFolder $xmlName
	CreateDirectory $xmlLocalDestination $xmlName

	#-----

	foreach($xmlTool in $xmlTools.TOOL)
	{
		$srcFile	= $null
		$destFolder	= $null
		
		$xmlToolName		= $xmlTool.NAME
		$xmlToolVer			= $xmlTool.VER
		$xmlToolFilename	= $xmlTool.FILENAME
		$xmlToolAction		= $xmlTool.ACTION
		
		Write-Host "PS1INSTALLER: Tool - $xmlToolName"
		Write-Host "PS1INSTALLER: Version - $xmlToolVer"
		Write-Host "PS1INSTALLER: Filename - $xmlToolFilename"
		
		#-----Download source file
		
		$xmlSrcFolder	= $xmlTool.PATH
		$xmlSrcFileName	= $xmlTool.FILENAME
		
		if ($xmlSrcFolder -ne "") { $srcFile = "{0}/{1}/{2}" -f $xmlSrcReposPath,$xmlSrcFolder,$xmlSrcFileName }
		else { $srcFile = "{0}/{1}" -f $xmlSrcReposPath,$xmlSrcFileName }
		if ($xmlSrcFolder -ne "") { $destFolder = "{0}\{1}" -f $xmlLocalDestination,$xmlSrcFolder }
		else { $destFolder = $xmlLocalDestination }
		
		$destFilePath = $destFolder + "\" + $xmlSrcFileName
			
		CreateDirectory $destFolder $xmlToolName
	
		DownloadFile $srcFile $xmlTempFolder $xmlToolName
		
		#-----
		
		switch($xmlToolAction) {
			"install" {
				#-----process install
				$srcType =  [System.IO.Path]::GetExtension($xmlSrcFileName).TrimStart(".")
				$cmdSwitches = $xmlTool.ARGS
				
				switch($srcType) {
					"exe" {
						$cmdToRun = $destFilePath
						InstallApp $cmdToRun $cmdSwitches $xmlToolName
					}
					"msi" {
						$cmdToRun = "msiexec"
						$cmdArgs = "/i$destFilePath $cmdSwitches"
						InstallApp $cmdToRun $cmdArgs $xmlToolName
					}
					default { }	
				}
			}
			"filecopy" {
				$srcFile = $xmlTempFolder + '\' + $xmlToolFilename
				CopyFile $srcFile $destFilePath $xmlToolName
			}
		}
	}

	#--- starting config items
	Write-Host "PS1INSTALLER: Starting config items"
	foreach($xmlConfigItem in $xmlConfigItems.CONFIGITEM) {
	    $xmlConifgName 		= $xmlConfigItem.NAME
		$xmlConfigAction	= $xmlConfigItem.ACTION
		
		Write-Host "PS1INSTALLER: Config item - $xmlConifgName"
		Write-Host "PS1INSTALLER: Action - $xmlConfigAction"

		switch($xmlConfigAction) {
	   		"registry" {
				$xmlRegKeyPath	= $xmlConfigItem.PATH
				$xmlRegKeyName	= $xmlConfigItem.KEYNAME
				$xmlRegKeyValue	= $xmlConfigItem.VALUE
					
				UpdateRegistry $xmlRegKeyPath $xmlRegKeyName $xmlRegKeyValue $xmlConifgName
			 }
			 "filecopy" {
				$xmlConfigSoure			= $xmlConfigItem.SOURCEFILE
				$xmlConfigDestination	= $xmlConfigItem.DESTINATIONFILE
				
				CopyFile $xmlConfigSoure $xmlConfigDestination $xmlConifgName
			}
		}
	}
}